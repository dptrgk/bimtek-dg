def classFactory(iface):
    from .latLonTools import LatLonTools
    return LatLonTools(iface)
